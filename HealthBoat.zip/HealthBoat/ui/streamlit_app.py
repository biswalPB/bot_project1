import json
from datetime import datetime

import streamlit as st

from graph.workflow import build_fitness_workflow
from ui.components import show_metrics, show_sources
from ui.feedback_form import feedback_form
from utils.constants import USE_CASE
from vectorstore.chroma_store import get_chroma_store


def main() -> None:
    st.set_page_config(page_title="Fitness AI Guide", layout="wide")
    st.title("Fitness AI Guide")

    with st.sidebar:
        st.header("Plan Inputs")
        goal = st.selectbox("Fitness goal", ["strength", "fat loss", "mobility", "endurance", "general wellness"])
        level = st.selectbox("Fitness level", ["beginner", "intermediate", "advanced"])
        equipment = st.multiselect(
            "Available equipment",
            ["bodyweight", "dumbbell", "barbell", "kettlebell", "resistance band", "machine", "cardio machine"],
            default=["bodyweight"],
        )
        days = st.slider("Days per week", 2, 6, 3)
        limitations = st.text_area("Safety notes or limitations", placeholder="Example: knee pain")

    query = st.text_area(
        "Ask for a workout plan or exercise guidance",
        value=f"Create a {days}-day {goal} workout plan for a {level} person using {', '.join(equipment)}.",
    )

    if "last_log_id" not in st.session_state:
        st.session_state.last_log_id = None

    if st.button("Generate validated plan", type="primary"):
        full_query = (
            f"{query}\n\nUser profile: goal={goal}; level={level}; equipment={', '.join(equipment)}; "
            f"days_per_week={days}; limitations={limitations or 'none'}."
        )
        workflow = build_fitness_workflow(get_chroma_store())
        with st.spinner("Running multi-agent LangGraph workflow..."):
            result = workflow.invoke(
                {
                    "query": full_query,
                    "intent": "",
                    "retrieved_chunks": [],
                    "draft_response": "",
                    "final_response": "",
                    "validation": {},
                    "accuracy": {},
                    "sources": [],
                    "use_case": USE_CASE,
                    "created_at": datetime.utcnow().isoformat(),
                }
            )
        st.session_state.last_result = result
        st.session_state.last_log_id = result.get("accuracy", {}).get("log_id")

    if "last_result" in st.session_state:
        result = st.session_state.last_result
        accuracy = result.get("accuracy", {})
        st.subheader("Validated Workout Response")
        st.write(result.get("final_response", "No response generated."))
        show_metrics(accuracy)

        if accuracy.get("confidence_level") == "LOW":
            st.warning("Lower confidence. Please verify with a qualified fitness or medical professional.")

        st.subheader("Validation Result")
        st.json(result.get("validation", {}))
        st.subheader("Source Citations")
        show_sources(result.get("sources", []))
        st.subheader("Accuracy Feedback")
        feedback_form(st.session_state.last_log_id)

        with st.expander("Raw graph output"):
            st.code(json.dumps(result, indent=2), language="json")


if __name__ == "__main__":
    main()

