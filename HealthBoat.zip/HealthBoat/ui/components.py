import streamlit as st


def show_metrics(accuracy: dict) -> None:
    cols = st.columns(4)
    cols[0].metric("Overall accuracy", f"{accuracy.get('overall_accuracy', 0):.1f}%")
    cols[1].metric("Faithfulness", f"{accuracy.get('faithfulness_score', 0):.1f}%")
    cols[2].metric("Relevance", f"{accuracy.get('relevance_score', 0):.1f}%")
    cols[3].metric("Confidence", accuracy.get("confidence_level", "LOW"))


def show_sources(sources: list[dict]) -> None:
    for source in sources:
        st.markdown(
            f"- **{source.get('source_file')}**, section `{source.get('section')}`, "
            f"score `{source.get('similarity_score'):.2f}`"
        )

