import streamlit as st

from agents.feedback_agent import save_feedback


def feedback_form(log_id: int | None) -> None:
    rating = st.slider("Was this response accurate? Rate 1-5 stars", 1, 5, 4)
    if st.button("Submit feedback"):
        if log_id:
            save_feedback(log_id, rating)
            st.success("Feedback saved.")
        else:
            st.error("No accuracy log found for this response.")

