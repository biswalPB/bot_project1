from config.settings import settings


def _bedrock_client():
    import boto3

    session_kwargs = {}
    if settings.aws_profile:
        session_kwargs["profile_name"] = settings.aws_profile

    session = boto3.Session(**session_kwargs)
    return session.client("bedrock-runtime", region_name=settings.aws_region)


def get_bedrock_llm(temperature: float = 0.2):
    if not settings.bedrock_model_id:
        raise RuntimeError("BEDROCK_MODEL_ID is not configured.")

    from langchain_aws import ChatBedrockConverse

    return ChatBedrockConverse(
        client=_bedrock_client(),
        model=settings.bedrock_model_id,
        temperature=temperature,
    )
