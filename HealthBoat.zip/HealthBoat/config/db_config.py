from pathlib import Path

from config.settings import settings


DB_PATH = Path(settings.sqlite_db)
SCHEMA_PATH = Path("database/schema.sql")

