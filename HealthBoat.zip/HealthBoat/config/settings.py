import os
from dataclasses import dataclass

from dotenv import load_dotenv


load_dotenv()


@dataclass(frozen=True)
class Settings:
    aws_region: str = os.getenv("AWS_REGION", "us-east-1")
    aws_profile: str = os.getenv("AWS_PROFILE", "")
    bedrock_model_id: str = os.getenv("BEDROCK_MODEL_ID", "anthropic.claude-3-haiku-20240307-v1:0")
    chroma_dir: str = os.getenv("CHROMA_DIR", "data/chroma_db")
    sqlite_db: str = os.getenv("SQLITE_DB", "database/logs.db")
    retrieval_top_k: int = int(os.getenv("RETRIEVAL_TOP_K", "5"))
    retrieval_threshold: float = float(os.getenv("RETRIEVAL_THRESHOLD", "0.70"))
    validation_threshold: float = float(os.getenv("VALIDATION_THRESHOLD", "70"))
    embedding_model: str = os.getenv("EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2")


settings = Settings()
