# Health & Fitness Guide

AWS Bedrock + LangGraph multi-agent RAG application for generating validated workout plans with safety checks, source citations, accuracy scoring, and user feedback logging.

## What We Are Building

This project implements the mandatory architecture from the project brief for use case 10: **Health & Fitness Guide**.

The app accepts a fitness goal, experience level, available equipment, and safety notes from the user. It then:

1. Classifies the request with a Supervisor Agent.
2. Retrieves relevant exercise and safety documents from ChromaDB.
3. Generates a workout plan with a Specialist Agent using Claude Haiku through AWS Bedrock.
4. Validates the generated response against retrieved sources.
5. Scores faithfulness, relevance, source coverage, and overall accuracy.
6. Shows citations and asks the user for a 1-5 star accuracy rating.
7. Stores metrics and user feedback in SQLite.

## Mandatory Components

| Component | Implementation |
| --- | --- |
| Vector DB | Local persistent ChromaDB at `data/chroma_db` |
| Embeddings | `sentence-transformers/all-MiniLM-L6-v2` through LangChain HuggingFace embeddings |
| Retriever Agent | Converts query to embeddings, retrieves top-K chunks, filters by relevance threshold |
| Specialist Agent | Uses AWS Bedrock Claude Haiku when configured; local fallback for demos |
| Validation Agent | Checks grounding, hallucinations, contraindications, completeness, contradictions |
| Accuracy Checker | Scores faithfulness, relevance, source coverage, confidence, logs to SQLite |
| Feedback Loop | Streamlit star rating saved into `database/logs.db` |
| Framework | LangGraph + LangChain |
| UI | Streamlit |

## Architecture

```text
[User Query]
    |
    v
[Supervisor Agent]
    |
    v
[Retriever Agent] -> ChromaDB
    |
    v
[Specialist Agent] -> AWS Bedrock Claude Haiku
    |
    v
[Validation Agent]
    |
    v
[Accuracy Checker] -> SQLite
    |
    v
[Final Response + Accuracy Score + Source Citations]
```

## Setup

Create and activate a virtual environment:

```bash
python -m venv .venv
.venv\Scripts\activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

Create environment variables:

```bash
copy .env.example .env
```

Edit `.env` with your AWS Bedrock details:

```text
AWS_REGION=us-east-1
AWS_PROFILE=
BEDROCK_MODEL_ID=anthropic.claude-3-haiku-20240307-v1:0
```

Authenticate with AWS using one of the standard SDK methods, such as environment variables, an AWS profile, or IAM role credentials. If you use a local profile, set `AWS_PROFILE` in `.env`.

```bash
aws configure sso
```

Seed the exercise dataset and build the vector database:

```bash
python scripts/generate_exercise_dataset.py
python scripts/ingest.py
```

Run the Streamlit app:

```bash
streamlit run app.py
```

## Folder Responsibilities

- `config/`: environment, AWS Bedrock, and database paths.
- `data/raw/`: exercise, workout guideline, and safety source documents.
- `data/processed/`: generated chunk metadata and embedding placeholders.
- `data/chroma_db/`: persistent local ChromaDB vector database.
- `embeddings/`: embedding model and chunking logic.
- `vectorstore/`: ChromaDB setup and retrieval.
- `agents/`: Supervisor, Retriever, Specialist, Validation, Accuracy Checker, and Feedback agents.
- `graph/`: LangGraph state, workflow nodes, and graph edges.
- `validators/`: grounding, hallucination, contradiction, completeness, and safety checks.
- `metrics/`: faithfulness, relevance, confidence, and source coverage scoring.
- `database/`: SQLite schema, manager, and runtime logs database.
- `prompts/`: prompt templates for agents.
- `services/`: AWS Bedrock, embedding, and response formatting services.
- `ui/`: Streamlit app components.
- `tests/`: focused tests for retriever, validator, accuracy, and graph compilation.

## Notes

- The generated exercise JSON contains 240 exercise records.
- If AWS Bedrock credentials or model access are missing, the app uses a local extractive fallback so the full graph can still be demonstrated.
- Default Bedrock model: Claude 3 Haiku (`anthropic.claude-3-haiku-20240307-v1:0`). You can switch to another enabled Bedrock model such as Titan Text Lite by changing `BEDROCK_MODEL_ID`.
- This is an educational fitness guide, not medical advice. Users with injuries, pain, pregnancy, heart conditions, or medical restrictions should consult a qualified professional.
