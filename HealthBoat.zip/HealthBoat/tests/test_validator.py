from validators.grounding_check import grounding_score


def test_grounding_flags_unsupported_claims():
    score, unsupported = grounding_score(
        "Do squats. Run a marathon tomorrow.",
        "Exercise: Squat. Beginners can use 2 sets of 8 reps.",
    )
    assert score < 100
    assert unsupported

