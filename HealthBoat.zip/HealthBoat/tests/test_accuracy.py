from metrics.confidence import confidence_level
from metrics.relevance import calculate_relevance


def test_confidence_bands():
    assert confidence_level(90) == "HIGH"
    assert confidence_level(75) == "MEDIUM"
    assert confidence_level(50) == "LOW"


def test_relevance_score():
    assert calculate_relevance("beginner strength squat", "beginner squat strength plan") > 0

