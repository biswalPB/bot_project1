from graph.workflow import build_fitness_workflow


def test_graph_compiles():
    class FakeStore:
        pass

    graph = build_fitness_workflow(FakeStore())
    assert graph is not None

