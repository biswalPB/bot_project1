from vectorstore.retriever import retrieve_relevant_chunks


class FakeStore:
    def similarity_search_with_score(self, query, k):
        from langchain_core.documents import Document

        return [
            (
                Document(
                    page_content="Exercise: Squat. Level: beginner. Equipment: bodyweight.",
                    metadata={"source_file": "test", "section": "strength"},
                ),
                0.1,
            )
        ]


def test_retriever_returns_chunks():
    chunks = retrieve_relevant_chunks(FakeStore(), "beginner squat")
    assert chunks
    assert chunks[0]["similarity_score"] > 0

