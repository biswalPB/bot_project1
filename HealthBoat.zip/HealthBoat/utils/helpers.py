import re


STOPWORDS = {
    "the", "and", "for", "with", "that", "this", "from", "your", "you", "are", "into",
    "workout", "plan", "exercise", "training", "using", "should", "will", "a", "an", "to",
}


def token_set(text: str) -> set[str]:
    return {
        token
        for token in re.findall(r"[a-zA-Z][a-zA-Z0-9-]+", text.lower())
        if token not in STOPWORDS
    }


def split_claims(text: str) -> list[str]:
    claims = [claim.strip() for claim in re.split(r"(?<=[.!?])\s+|\n+", text) if claim.strip()]
    return [claim for claim in claims if len(token_set(claim)) >= 3]

