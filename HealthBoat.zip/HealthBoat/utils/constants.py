USE_CASE = "health_fitness_guide"
LOW_CONFIDENCE_MESSAGE = "Lower confidence. Please verify."

