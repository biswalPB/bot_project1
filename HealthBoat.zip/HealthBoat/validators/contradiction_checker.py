def check_contradictions(query: str, response: str) -> list[str]:
    flags: list[str] = []
    lowered_query = query.lower()
    lowered_response = response.lower()
    if "pain" in lowered_query and "ignore pain" in lowered_response:
        flags.append("Response tells the user to ignore pain, which contradicts safety guidance.")
    if "beginner" in lowered_query and "maximum effort" in lowered_response:
        flags.append("Response recommends maximum effort for a beginner.")
    return flags

