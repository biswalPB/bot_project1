from utils.helpers import split_claims, token_set


def claim_is_grounded(claim: str, source_text: str) -> bool:
    claim_tokens = token_set(claim)
    if not claim_tokens:
        return True
    source_tokens = token_set(source_text)
    overlap = len(claim_tokens & source_tokens) / max(1, len(claim_tokens))
    return overlap >= 0.45


def grounding_score(response: str, source_text: str) -> tuple[float, list[str]]:
    claims = split_claims(response)
    unsupported = [claim for claim in claims if not claim_is_grounded(claim, source_text)]
    supported = max(0, len(claims) - len(unsupported))
    score = 100.0 if not claims else (supported / len(claims)) * 100
    return score, unsupported

