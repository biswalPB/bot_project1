from validators.grounding_check import grounding_score


def detect_hallucinations(response: str, source_text: str) -> list[str]:
    _, unsupported = grounding_score(response, source_text)
    return unsupported

