SAFETY_TERMS = {"pain", "injury", "pregnant", "heart", "dizzy", "surgery", "blood pressure"}


def is_safety_sensitive(query: str) -> bool:
    lowered = query.lower()
    return any(term in lowered for term in SAFETY_TERMS)


def safety_warning_needed(query: str, response: str) -> bool:
    return is_safety_sensitive(query) and "consult" not in response.lower()

