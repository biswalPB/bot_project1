"""External and internal service modules."""

