def format_context(chunks: list[dict]) -> str:
    return "\n\n".join(
        f"Source {index + 1}: {chunk['source_file']} | {chunk['section']} | {chunk['content']}"
        for index, chunk in enumerate(chunks)
    )


def source_citations(chunks: list[dict]) -> list[dict]:
    return [
        {
            "source_file": chunk["source_file"],
            "page_number": chunk["page_number"],
            "section": chunk["section"],
            "similarity_score": chunk["similarity_score"],
        }
        for chunk in chunks
    ]

