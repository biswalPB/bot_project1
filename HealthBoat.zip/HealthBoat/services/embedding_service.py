from embeddings.embedder import get_embedder


def embed_query(query: str) -> list[float]:
    return get_embedder().embed_query(query)

