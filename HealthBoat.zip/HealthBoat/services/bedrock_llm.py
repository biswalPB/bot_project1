from config.bedrock_config import get_bedrock_llm


def generate_with_bedrock(prompt: str) -> str:
    llm = get_bedrock_llm()
    response = llm.invoke(prompt)
    return str(response.content)
