from langchain_community.embeddings import HuggingFaceEmbeddings

from config.settings import settings


def get_embedder() -> HuggingFaceEmbeddings:
    return HuggingFaceEmbeddings(model_name=settings.embedding_model)

