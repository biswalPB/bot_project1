"""Embedding and chunking modules."""

