from validators.grounding_check import grounding_score


def calculate_faithfulness(response: str, source_text: str) -> float:
    score, _ = grounding_score(response, source_text)
    return score

