from utils.helpers import token_set


def calculate_source_coverage(response: str, chunks: list[dict]) -> float:
    response_tokens = token_set(response)
    used = 0
    for chunk in chunks:
        chunk_tokens = token_set(chunk["content"])
        if chunk_tokens and len(chunk_tokens & response_tokens) / len(chunk_tokens) >= 0.20:
            used += 1
    return 100.0 * used / max(1, len(chunks))

