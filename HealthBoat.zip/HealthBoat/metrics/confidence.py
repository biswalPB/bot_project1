def confidence_level(overall_accuracy: float) -> str:
    if overall_accuracy > 85:
        return "HIGH"
    if overall_accuracy >= 70:
        return "MEDIUM"
    return "LOW"

