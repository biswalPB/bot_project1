from utils.helpers import token_set


def calculate_relevance(query: str, response: str) -> float:
    query_tokens = token_set(query)
    response_tokens = token_set(response)
    return 100.0 * len(query_tokens & response_tokens) / max(1, len(query_tokens))

