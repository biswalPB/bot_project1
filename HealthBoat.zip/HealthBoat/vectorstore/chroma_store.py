from pathlib import Path

from langchain_chroma import Chroma

from config.settings import settings
from embeddings.embedder import get_embedder


COLLECTION_NAME = "fitness_ai_knowledge"


def get_chroma_store() -> Chroma:
    Path(settings.chroma_dir).mkdir(parents=True, exist_ok=True)
    return Chroma(
        collection_name=COLLECTION_NAME,
        embedding_function=get_embedder(),
        persist_directory=settings.chroma_dir,
    )

