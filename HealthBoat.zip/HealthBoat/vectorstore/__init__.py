"""Vector store and retrieval modules."""

