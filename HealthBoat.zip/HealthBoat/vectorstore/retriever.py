from typing import Any

from langchain_core.documents import Document

from config.settings import settings


def _format_chunk(document: Document, distance: float) -> dict[str, Any]:
    metadata = dict(document.metadata)
    return {
        "content": document.page_content,
        "source_file": metadata.get("source_file", "unknown"),
        "page_number": metadata.get("page_number", 1),
        "section": metadata.get("section", "general"),
        "exercise": metadata.get("exercise", ""),
        "level": metadata.get("level", ""),
        "equipment": metadata.get("equipment", ""),
        "similarity_score": max(0.0, 1.0 - float(distance)),
    }


def retrieve_relevant_chunks(vector_store: Any, query: str) -> list[dict[str, Any]]:
    docs_with_scores = vector_store.similarity_search_with_score(query, k=settings.retrieval_top_k)
    chunks = [_format_chunk(doc, score) for doc, score in docs_with_scores]
    filtered = [chunk for chunk in chunks if chunk["similarity_score"] >= settings.retrieval_threshold]
    return filtered or chunks[: min(3, len(chunks))]

