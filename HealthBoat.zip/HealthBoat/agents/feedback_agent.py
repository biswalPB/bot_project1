from database.sqlite_manager import SQLiteManager


def save_feedback(log_id: int, rating: int) -> None:
    SQLiteManager().update_user_rating(log_id, rating)

