from services.response_formatter import source_citations
from vectorstore.retriever import retrieve_relevant_chunks


def make_retriever_agent(vector_store):
    def retriever_agent(state: dict) -> dict:
        chunks = retrieve_relevant_chunks(vector_store, state["query"])
        return {"retrieved_chunks": chunks, "sources": source_citations(chunks)}

    return retriever_agent

