from database.sqlite_manager import SQLiteManager
from metrics.confidence import confidence_level
from metrics.relevance import calculate_relevance
from metrics.source_coverage import calculate_source_coverage
from utils.constants import LOW_CONFIDENCE_MESSAGE


def accuracy_checker(state: dict) -> dict:
    validation = state.get("validation", {})
    response = state.get("final_response", "")
    faithfulness = float(validation.get("source_grounding_score", 0))
    relevance = calculate_relevance(state["query"], response)
    coverage = calculate_source_coverage(response, state.get("retrieved_chunks", []))
    overall = (faithfulness * 0.45) + (relevance * 0.30) + (coverage * 0.25)
    confidence = confidence_level(overall)

    if confidence == "LOW" and LOW_CONFIDENCE_MESSAGE not in response:
        response += f"\n\n{LOW_CONFIDENCE_MESSAGE}"

    db = SQLiteManager()
    log_id = db.insert_accuracy_log(
        {
            "query": state["query"],
            "response": response,
            "faithfulness_score": faithfulness,
            "relevance_score": relevance,
            "confidence_level": confidence,
            "sources_used": state.get("sources", []),
            "validation_result": validation.get("decision", "REJECT"),
            "use_case": state.get("use_case", "health_fitness_guide"),
        }
    )

    return {
        "final_response": response,
        "accuracy": {
            "faithfulness_score": round(faithfulness, 2),
            "relevance_score": round(relevance, 2),
            "source_coverage": round(coverage, 2),
            "overall_accuracy": round(overall, 2),
            "confidence_level": confidence,
            "log_id": log_id,
            "feedback_prompt": "Was this response accurate? Rate 1-5 stars.",
        },
    }

