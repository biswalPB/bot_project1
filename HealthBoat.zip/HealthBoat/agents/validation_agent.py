from config.settings import settings
from validators.completeness_checker import completeness_score
from validators.contradiction_checker import check_contradictions
from validators.grounding_check import grounding_score
from validators.safety_validator import safety_warning_needed


def validation_agent(state: dict) -> dict:
    response = state.get("draft_response", "")
    source_text = " ".join(chunk["content"] for chunk in state.get("retrieved_chunks", []))
    faithfulness, unsupported = grounding_score(response, source_text)
    completeness = completeness_score(state["query"], response)
    contradictions = check_contradictions(state["query"], response)

    if safety_warning_needed(state["query"], response):
        contradictions.append("Safety-sensitive request does not include professional consultation guidance.")

    if faithfulness < settings.validation_threshold or contradictions:
        decision = "REVISE" if faithfulness >= 50 and not contradictions else "REJECT"
    else:
        decision = "PASS"

    final_response = response
    if unsupported:
        final_response += "\n\nValidation note: Unsupported or weakly grounded claims were flagged. Verify before use."

    return {
        "validation": {
            "decision": decision,
            "source_grounding_score": round(faithfulness, 2),
            "completeness_score": round(min(100.0, completeness), 2),
            "unsupported_claims": unsupported[:5],
            "hallucination_count": len(unsupported),
            "contradictions": contradictions,
        },
        "final_response": final_response,
    }

