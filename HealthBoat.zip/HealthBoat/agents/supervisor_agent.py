from validators.safety_validator import is_safety_sensitive


def supervisor_agent(state: dict) -> dict:
    query = state["query"].lower()
    if is_safety_sensitive(query):
        intent = "safety_sensitive_workout_plan"
    elif "mobility" in query or "stretch" in query:
        intent = "mobility_guidance"
    elif "fat loss" in query or "weight" in query:
        intent = "fat_loss_workout_plan"
    elif "endurance" in query or "cardio" in query:
        intent = "endurance_guidance"
    elif "strength" in query:
        intent = "strength_workout_plan"
    else:
        intent = "general_fitness_guidance"
    return {"intent": intent}

