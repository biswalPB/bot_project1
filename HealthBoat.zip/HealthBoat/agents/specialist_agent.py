from config.settings import settings
from services.response_formatter import format_context
from services.bedrock_llm import generate_with_bedrock


def _fallback_response(state: dict) -> str:
    chunks = state.get("retrieved_chunks", [])
    lines = ["Validated workout guidance based on retrieved fitness sources:", ""]
    for index, chunk in enumerate(chunks[:5], start=1):
        exercise = chunk.get("exercise") or chunk.get("section")
        lines.append(f"{index}. {exercise}: {chunk['content']} [Source {index}]")
    lines.extend(
        [
            "",
            "Safety check: Stop if sharp pain, dizziness, chest pain, or unusual shortness of breath occurs.",
            "Use easier variations when form breaks down and consult a qualified professional for medical limitations.",
        ]
    )
    return "\n".join(lines)


def specialist_agent(state: dict) -> dict:
    context = format_context(state.get("retrieved_chunks", []))
    prompt = f"""
You are a fitness planning specialist for an educational wellness app.
Use only the retrieved source context. Do not invent exercises, rep ranges, contraindications, or safety claims.

Intent:
{state.get("intent", "general_fitness_guidance")}

User request:
{state["query"]}

Retrieved context:
{context}

Create a concise workout plan with exercises, sets, reps, rest, weekly structure, safety notes, and source citations.
"""
    if settings.bedrock_model_id:
        try:
            return {"draft_response": generate_with_bedrock(prompt)}
        except Exception as exc:
            return {"draft_response": f"{_fallback_response(state)}\n\nAWS Bedrock fallback reason: {exc}"}
    return {"draft_response": _fallback_response(state)}
