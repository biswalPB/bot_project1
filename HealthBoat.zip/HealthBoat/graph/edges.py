from langgraph.graph import END


def add_workflow_edges(workflow) -> None:
    workflow.set_entry_point("supervisor")
    workflow.add_edge("supervisor", "retriever")
    workflow.add_edge("retriever", "specialist")
    workflow.add_edge("specialist", "validator")
    workflow.add_edge("validator", "accuracy_checker")
    workflow.add_edge("accuracy_checker", END)

