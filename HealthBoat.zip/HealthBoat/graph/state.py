from typing import Any, TypedDict


class FitnessGraphState(TypedDict):
    query: str
    intent: str
    retrieved_chunks: list[dict[str, Any]]
    draft_response: str
    final_response: str
    validation: dict[str, Any]
    accuracy: dict[str, Any]
    sources: list[dict[str, Any]]
    use_case: str
    created_at: str

