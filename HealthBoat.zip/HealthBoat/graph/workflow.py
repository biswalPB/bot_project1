from langgraph.graph import StateGraph

from agents.accuracy_checker import accuracy_checker
from agents.retriever_agent import make_retriever_agent
from agents.specialist_agent import specialist_agent
from agents.supervisor_agent import supervisor_agent
from agents.validation_agent import validation_agent
from graph.edges import add_workflow_edges
from graph.state import FitnessGraphState


def build_fitness_workflow(vector_store):
    workflow = StateGraph(FitnessGraphState)
    workflow.add_node("supervisor", supervisor_agent)
    workflow.add_node("retriever", make_retriever_agent(vector_store))
    workflow.add_node("specialist", specialist_agent)
    workflow.add_node("validator", validation_agent)
    workflow.add_node("accuracy_checker", accuracy_checker)
    add_workflow_edges(workflow)
    return workflow.compile()

