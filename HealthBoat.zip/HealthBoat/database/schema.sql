CREATE TABLE IF NOT EXISTS accuracy_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    query TEXT NOT NULL,
    response TEXT NOT NULL,
    faithfulnessscore FLOAT NOT NULL,
    relevancescore FLOAT NOT NULL,
    confidencelevel TEXT NOT NULL,
    userrating INTEGER,
    sourcesused TEXT NOT NULL,
    validationresult TEXT NOT NULL,
    use_case TEXT NOT NULL
);

