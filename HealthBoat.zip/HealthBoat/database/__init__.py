"""SQLite persistence modules."""

