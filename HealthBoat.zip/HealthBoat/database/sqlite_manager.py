import json
import sqlite3
from pathlib import Path
from typing import Any

from config.db_config import DB_PATH, SCHEMA_PATH


class SQLiteManager:
    def __init__(self, db_path: Path = DB_PATH) -> None:
        self.db_path = db_path
        self.init_db()

    def connect(self) -> sqlite3.Connection:
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        return sqlite3.connect(self.db_path)

    def init_db(self) -> None:
        schema = SCHEMA_PATH.read_text(encoding="utf-8")
        with self.connect() as conn:
            conn.executescript(schema)

    def insert_accuracy_log(self, payload: dict[str, Any]) -> int:
        with self.connect() as conn:
            cursor = conn.execute(
                """
                INSERT INTO accuracy_logs (
                    query, response, faithfulnessscore, relevancescore, confidencelevel,
                    userrating, sourcesused, validationresult, use_case
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    payload["query"],
                    payload["response"],
                    payload["faithfulness_score"],
                    payload["relevance_score"],
                    payload["confidence_level"],
                    payload.get("user_rating"),
                    json.dumps(payload["sources_used"]),
                    payload["validation_result"],
                    payload["use_case"],
                ),
            )
            return int(cursor.lastrowid)

    def update_user_rating(self, log_id: int, rating: int) -> None:
        with self.connect() as conn:
            conn.execute("UPDATE accuracy_logs SET userrating = ? WHERE id = ?", (rating, log_id))

