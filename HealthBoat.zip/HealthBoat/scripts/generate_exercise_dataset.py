import json
from pathlib import Path

OUTPUT = Path("data/raw/exercises.json")

MOVEMENTS = [
    ("Squat", "legs", "strength", "bodyweight", "beginner"),
    ("Goblet Squat", "legs", "strength", "dumbbell", "beginner"),
    ("Front Squat", "legs", "strength", "barbell", "advanced"),
    ("Romanian Deadlift", "posterior chain", "strength", "dumbbell", "intermediate"),
    ("Hip Hinge Drill", "posterior chain", "mobility", "bodyweight", "beginner"),
    ("Glute Bridge", "glutes", "strength", "bodyweight", "beginner"),
    ("Reverse Lunge", "legs", "strength", "bodyweight", "beginner"),
    ("Step Up", "legs", "endurance", "bodyweight", "beginner"),
    ("Push Up", "chest", "strength", "bodyweight", "beginner"),
    ("Incline Push Up", "chest", "strength", "bodyweight", "beginner"),
    ("Dumbbell Bench Press", "chest", "strength", "dumbbell", "intermediate"),
    ("Overhead Press", "shoulders", "strength", "dumbbell", "intermediate"),
    ("Band Pull Apart", "upper back", "mobility", "resistance band", "beginner"),
    ("One Arm Row", "back", "strength", "dumbbell", "beginner"),
    ("Lat Pulldown", "back", "strength", "machine", "beginner"),
    ("Plank", "core", "strength", "bodyweight", "beginner"),
    ("Dead Bug", "core", "mobility", "bodyweight", "beginner"),
    ("Side Plank", "core", "strength", "bodyweight", "intermediate"),
    ("Kettlebell Swing", "posterior chain", "endurance", "kettlebell", "intermediate"),
    ("Farmer Carry", "full body", "strength", "dumbbell", "beginner"),
    ("Jump Rope", "cardio", "fat loss", "bodyweight", "intermediate"),
    ("Treadmill Walk", "cardio", "fat loss", "cardio machine", "beginner"),
    ("Bike Intervals", "cardio", "endurance", "cardio machine", "intermediate"),
    ("Rowing Machine", "cardio", "endurance", "cardio machine", "intermediate"),
]

VARIANTS = [
    ("standard", "2-3", "8-12", "60-90 seconds", "Use controlled tempo and stop if technique changes."),
    ("light technique", "1-2", "10-15", "45-75 seconds", "Choose an easy version and keep effort moderate."),
    ("strength focus", "3-4", "5-8", "90-180 seconds", "Use heavier resistance only with stable form."),
    ("endurance focus", "2-4", "12-20", "30-60 seconds", "Keep breathing steady and reduce speed if form breaks."),
    ("mobility focus", "1-3", "6-10 slow reps", "30-60 seconds", "Move through a comfortable pain-free range."),
    ("low impact", "2-3", "8-15", "45-90 seconds", "Avoid jumping and use a smooth range of motion."),
    ("beginner regression", "1-3", "6-10", "60-120 seconds", "Decrease range or resistance when needed."),
    ("advanced progression", "3-5", "6-12", "90-180 seconds", "Progress load gradually and avoid failure on complex lifts."),
    ("home workout", "2-4", "8-15", "45-90 seconds", "Use household space safely and maintain balance."),
    ("conditioning circuit", "2-5", "30-45 seconds", "30-75 seconds", "Keep intensity below the point where form breaks."),
]


def main() -> None:
    rows = []
    for movement, muscle_group, goal, equipment, level in MOVEMENTS:
        for variant, sets, reps, rest, safety_note in VARIANTS:
            rows.append(
                {
                    "exercise": f"{movement} - {variant}",
                    "base_movement": movement,
                    "muscle_group": muscle_group,
                    "goal": goal,
                    "equipment": equipment,
                    "level": level,
                    "sets": sets,
                    "reps": reps,
                    "rest": rest,
                    "contraindications": "Avoid or modify with acute pain, dizziness, recent surgery, or medical restrictions.",
                    "safety_notes": safety_note,
                    "description": (
                        f"{movement} targets {muscle_group} for {goal}. Recommended for {level} users with "
                        f"{equipment}. Use {sets} sets of {reps} with {rest} rest. {safety_note}"
                    ),
                }
            )
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(json.dumps(rows, indent=2), encoding="utf-8")
    print(f"Wrote {len(rows)} records to {OUTPUT}")


if __name__ == "__main__":
    main()
