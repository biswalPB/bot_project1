import json
from pathlib import Path

import pandas as pd
from langchain_core.documents import Document

from embeddings.chunker import chunk_documents
from vectorstore.chroma_store import get_chroma_store


EXERCISES_JSON = Path("data/raw/exercises.json")
GUIDELINES_CSV = Path("data/raw/workout_guidelines.csv")
SAFETY_JSON = Path("data/raw/safety_rules.json")
CHUNKS_JSON = Path("data/processed/chunks.json")


def build_documents() -> list[Document]:
    documents: list[Document] = []

    exercises = json.loads(EXERCISES_JSON.read_text(encoding="utf-8"))
    for row_number, row in enumerate(exercises, start=1):
        content = (
            f"Exercise: {row['exercise']}. Goal: {row['goal']}. Level: {row['level']}. "
            f"Equipment: {row['equipment']}. Sets: {row['sets']}. Reps: {row['reps']}. "
            f"Rest: {row['rest']}. Safety notes: {row['safety_notes']}. "
            f"Contraindications: {row['contraindications']}."
        )
        documents.append(
            Document(
                page_content=content,
                metadata={
                    "source_file": str(EXERCISES_JSON),
                    "page_number": row_number,
                    "section": f"{row['goal']}_{row['level']}",
                    "exercise": row["exercise"],
                    "level": row["level"],
                    "equipment": row["equipment"],
                },
            )
        )

    guideline_df = pd.read_csv(GUIDELINES_CSV)
    for row_number, row in guideline_df.iterrows():
        documents.append(
            Document(
                page_content=str(row["content"]),
                metadata={
                    "source_file": str(GUIDELINES_CSV),
                    "page_number": int(row_number) + 1,
                    "section": row["section"],
                },
            )
        )

    safety_items = json.loads(SAFETY_JSON.read_text(encoding="utf-8"))
    for index, item in enumerate(safety_items, start=1):
        documents.append(
            Document(
                page_content=item["content"],
                metadata={
                    "source_file": str(SAFETY_JSON),
                    "page_number": index,
                    "section": item["section"],
                },
            )
        )
    return documents


def main() -> None:
    chunks = chunk_documents(build_documents())
    CHUNKS_JSON.parent.mkdir(parents=True, exist_ok=True)
    CHUNKS_JSON.write_text(
        json.dumps(
            [{"content": chunk.page_content, "metadata": chunk.metadata} for chunk in chunks],
            indent=2,
        ),
        encoding="utf-8",
    )
    vector_store = get_chroma_store()
    vector_store.reset_collection()
    vector_store.add_documents(chunks)
    print(f"Ingested {len(chunks)} chunks into ChromaDB.")


if __name__ == "__main__":
    main()
