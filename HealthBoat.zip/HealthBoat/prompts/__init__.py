"""Prompt assets package marker."""

